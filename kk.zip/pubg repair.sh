
rm -rf  /data/data/com.tencent.ig/files
rm -rf /data/data/com.tencent.ig/files
rm -rf /data/data/com.tencent.ig/app_crashrecord
rm -rf /data/data/com.tencent.ig/app_crashrecord
rm -rf /data/data/com.tencent.ig/cache/*

echo "wait.."
rm -rf  /data/data/com.pubg.krmobile/files
rm -rf /data/data/com.pubg.krmobile/files
rm -rf /data/data/com.pubg.krmobile/app_crashrecord
rm -rf /data/data/com.pubg.krmobile/app_crashrecord
rm -rf /data/data/com.pubg.krmobile/cache/*

echo "wait.."
rm -rf  /data/data/com.rekoo.pubgm/files
rm -rf /data/data/com.rekoo.pubgm/files
rm -rf /data/data/com.rekoo.pubgm/app_crashrecord
rm -rf /data/data/com.rekoo.pubgm/app_crashrecord
rm -rf /data/data/com.rekoo.pubgm/cache/*

echo "wait.."
rm -rf  /data/data/com.tencent.iglite/files
rm -rf /data/data/com.tencent.iglite/files
rm -rf /data/data/com.tencent.iglite/app_crashrecord
rm -rf /data/data/com.tencent.iglite/app_crashrecord
rm -rf /data/data/com.tencent.iglite/cache/*

echo "wait.."
chmod -R 755 /data/data/com.tencent.ig/files/ano_tmp

chmod -R 755 /data/data/com.pubg.krmobile/files/ano_tmp

chmod -R 755 /data/data/com.vng.pubgmobile/files/ano_tmp

chmod -R 755 /data/data/com.rekoo.pubgm/files/ano_tmp

echo "wait.."

rm -rf /data/data/com.tencent.ig/files/ano_tmp/tssmua.zip
rm -rf /data/data/com.tencent.ig/files/ano_tmp/tssmua.zip
rm -rf /data/data/com.tencent.ig/files/ano_tmp/config3.xml
rm -rf /data/data/com.tencent.ig/files/ano_tmp/config3.xml
rm -rf /data/data/com.tencent.ig/files/ano_tmp/comm.dat
rm -rf /data/data/com.tencent.ig/files/ano_tmp/comm.dat
chmod -R 755 /data/data/com.tencent.ig/files/ano_tmp/tssmua.zip
chmod -R 755 /data/data/com.tencent.ig/files/ano_tmp/config3.xml
chmod -R 755 /data/data/com.tencent.ig/files/ano_tmp/comm.dat

rm -rf /data/data/com.pubg.krmobile/files/ano_tmp/tssmua.zip
rm -rf /data/data/com.pubg.krmobile/files/ano_tmp/tssmua.zip
rm -rf /data/data/com.pubg.krmobile/files/ano_tmp/config3.xml
rm -rf /data/data/com.pubg.krmobile/files/ano_tmp/config3.xml
rm -rf /data/data/com.pubg.krmobile/files/ano_tmp/comm.dat
rm -rf /data/data/com.pubg.krmobile/files/ano_tmp/comm.dat
chmod -R 755 /data/data/com.pubg.krmobile/files/ano_tmp/tssmua.zip
chmod -R 755 /data/data/com.pubg.krmobile/files/ano_tmp/config3.xml
chmod -R 755 /data/data/com.pubg.krmobile/files/ano_tmp/comm.dat

rm -rf /data/data/com.vng.pubgmobile/files/ano_tmp/tssmua.zip
rm -rf /data/data/com.vng.pubgmobile/files/ano_tmp/tssmua.zip
rm -rf /data/data/com.vng.pubgmobile/files/ano_tmp/config3.xml
rm -rf /data/data/com.vng.pubgmobile/files/ano_tmp/config3.xml
rm -rf /data/data/com.vng.pubgmobile/files/ano_tmp/comm.dat
rm -rf /data/data/com.vng.pubgmobile/files/ano_tmp/comm.dat
chmod -R 755 /data/data/com.vng.pubgmobile/files/ano_tmp/tssmua.zip
chmod -R 755 /data/data/com.vng.pubgmobile/files/ano_tmp/config3.xml
chmod -R 755 /data/data/com.vng.pubgmobile/files/ano_tmp/comm.dat


rm -rf /data/data/com.rekoo.pubgm/files/ano_tmp/tssmua.zip
rm -rf /data/data/com.rekoo.pubgm/files/ano_tmp/tssmua.zip
rm -rf /data/data/com.rekoo.pubgm/files/ano_tmp/config3.xml
rm -rf /data/data/com.rekoo.pubgm/files/ano_tmp/config3.xml
rm -rf /data/data/com.rekoo.pubgm/files/ano_tmp/comm.dat
rm -rf /data/data/com.rekoo.pubgm/files/ano_tmp/comm.dat
chmod -R 755 /data/data/com.rekoo.pubgm/files/ano_tmp/tssmua.zip
chmod -R 755 /data/data/com.rekoo.pubgm/files/ano_tmp/config3.xml
chmod -R 755 /data/data/com.rekoo.pubgm/files/ano_tmp/comm.dat

chmod 755 /data/data/com.tencent.ig/files/ano_tmp

chmod 755 /data/data/com.pubg.krmobile/files/ano_tmp

chmod 755 /data/data/com.vng.pubgmobile/files/ano_tmp

chmod 755 /data/data/com.rekoo.pubgm/files/ano_tmp

rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_*

chmod 755 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
chmod 755 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 755 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
chmod 755 /data/data/com.pubg.krmobile/databases

rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_*

chmod 755 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
chmod 755 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 755 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
chmod 755 /data/data/com.tencent.ig/databases

rm -rf /sdcard/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_*

chmod 755 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
chmod 755 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 755 /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
chmod 755 /data/data/com.pubg.imobile/databases

rm -rf /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_*

chmod 755 /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
chmod 755 /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 755 /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
chmod 755 /data/data/com.vng.pubgmobile/databases

rm -rf /sdcard/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_*

chmod 755 /data/media/0/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
chmod 755 /data/media/0/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 755 /data/media/0/Android/data/com.tencent.iglite/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
chmod 755 /data/data/com.tencent.iglite/databases

rm -rf /sdcard/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_*

chmod 755 /data/media/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
chmod 755 /data/media/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 755 /data/media/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
chmod 755 /data/data/com.rekoo.pubgm/databases
echo "                 By @leodeviq            "
exit

    
    



#/data/data/com.tencent.mobileqqh/data/data/user/0/com.tencent.ig/